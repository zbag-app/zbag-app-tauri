# tauri-cef-tls-repro

Minimal Tauri v2 + CEF runtime reproduction of an HTTPS hang that appears when
`reqwest 0.13` (default `rustls` feature) and `tonic 0.14` share a process.

## Symptom

In the default (broken) build, click order matters:

1. `Test reqwest` returns `200` quickly.
2. `Test tonic` never completes, times out after 25 s.

Without clicking reqwest first, tonic may also panic on missing default
CryptoProvider. The point of the repro is the combined path.

## Hypothesis

`reqwest 0.13` pulls `aws-lc-rs` + `rustls-platform-verifier`. On first use it
installs `aws-lc-rs` as the global default `rustls::crypto::CryptoProvider`.
`tonic 0.14` later does its own TLS handshake, picks up the default provider
(`aws-lc-rs`), and that handshake hangs inside a process that also statically
links CEF's Chromium BoringSSL.

Phase A isolation in the parent zSTASH project confirmed that installing
`ring` as the default provider before any TLS use fixes the hang.

## Variants

Two feature variants share the same binary:

- **Broken** (default): `cargo tauri build --features cef-runtime --bundles app`
- **Fixed**: `cargo tauri build --features cef-runtime,install-ring --bundles app`
  Installs `ring` as the rustls default provider before any TLS call.

Expected: broken hangs on the tonic button, fixed completes in < 2 s.

## Build + run

Requires Rust 1.92, `cargo-tauri` CLI
(`cargo install tauri-cli --version ^2.0 --locked`), macOS arm64.

```
cd src-tauri
cargo tauri build --features cef-runtime --bundles app
rm -f /tmp/repro-probe.log
open -na "../target/release/bundle/macos/tauri-cef-tls-repro.app"
# wait ~90s, the auto-probe runs on startup and writes /tmp/repro-probe.log
cat /tmp/repro-probe.log
```

No button clicks needed; the app runs two TLS probes in the Tauri setup hook
and logs results to `/tmp/repro-probe.log`.

For the fixed variant:

```
cargo tauri build --features cef-runtime,install-ring --bundles app
rm -f /tmp/repro-probe.log
open -na "../target/release/bundle/macos/tauri-cef-tls-repro.app"
cat /tmp/repro-probe.log
```

The app passes `--password-store=basic --use-mock-keychain` to CEF so
re-launches after rebuild don't prompt for macOS keychain access.

## Toolchain pins

- `tauri` + `tauri-build` pinned to `tauri-apps/tauri@562bc592` (the CEF feat branch snapshot).
- `reqwest 0.13` with default `rustls` feature (`aws-lc-rs` + `rustls-platform-verifier`).
- `tonic 0.14` with `tls-ring` + `tls-webpki-roots`.

## Not included

No frontend framework, no wallet logic, no zSTASH crates. Plain HTML.
