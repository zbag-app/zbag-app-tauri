#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    tauri_cef_tls_repro_lib::run()
}
