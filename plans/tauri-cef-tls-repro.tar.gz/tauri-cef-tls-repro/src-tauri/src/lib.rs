use std::time::Duration;

use tauri::Manager;

const LOG_PATH: &str = "/tmp/repro-probe.log";

fn log(line: String) {
    eprintln!("{line}");
    if let Ok(mut f) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(LOG_PATH)
    {
        use std::io::Write as _;
        let _ = writeln!(f, "{line}");
    }
}

fn variant_label() -> &'static str {
    #[cfg(feature = "install-ring")]
    {
        "fixed (ring installed as default)"
    }
    #[cfg(not(feature = "install-ring"))]
    {
        "broken (no explicit provider install)"
    }
}

async fn do_reqwest() -> String {
    let t0 = std::time::Instant::now();
    let client = match reqwest::Client::builder()
        .timeout(Duration::from_secs(20))
        .build()
    {
        Ok(c) => c,
        Err(e) => return format!("reqwest build err: {e}"),
    };
    match tokio::time::timeout(
        Duration::from_secs(25),
        client.get("https://www.google.com").send(),
    )
    .await
    {
        Ok(Ok(r)) => format!(
            "reqwest ok status={} elapsed_ms={}",
            r.status().as_u16(),
            t0.elapsed().as_millis()
        ),
        Ok(Err(e)) => format!("reqwest err: {e} elapsed_ms={}", t0.elapsed().as_millis()),
        Err(_) => format!("reqwest TIMEOUT elapsed_ms={}", t0.elapsed().as_millis()),
    }
}

async fn do_tonic() -> String {
    let t0 = std::time::Instant::now();
    let ep = match tonic::transport::Endpoint::new("https://zec.rocks:443") {
        Ok(e) => e.connect_timeout(Duration::from_secs(20)),
        Err(e) => return format!("tonic endpoint err: {e}"),
    };
    match tokio::time::timeout(Duration::from_secs(25), ep.connect()).await {
        Ok(Ok(_)) => format!("tonic ok elapsed_ms={}", t0.elapsed().as_millis()),
        Ok(Err(e)) => format!("tonic err: {e} elapsed_ms={}", t0.elapsed().as_millis()),
        Err(_) => format!("tonic TIMEOUT elapsed_ms={}", t0.elapsed().as_millis()),
    }
}

#[tauri::command]
async fn test_reqwest() -> Result<String, String> {
    Ok(do_reqwest().await)
}

#[tauri::command]
async fn test_tonic() -> Result<String, String> {
    Ok(do_tonic().await)
}

pub fn run() {
    #[cfg(feature = "install-ring")]
    {
        let _ = rustls::crypto::ring::default_provider().install_default();
    }

    let _ = std::fs::remove_file(LOG_PATH);
    log(format!("[repro] startup variant={}", variant_label()));

    tauri::Builder::default()
        .command_line_args([
            ("password-store", Some("basic")),
            ("use-mock-keychain", None),
        ])
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![test_reqwest, test_tonic])
        .setup(|app| {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.set_title(&format!("Tauri CEF TLS repro [{}]", variant_label()));
            }

            tauri::async_runtime::spawn(async {
                log("[repro] probe reqwest start".into());
                let r = do_reqwest().await;
                log(format!("[repro] probe reqwest => {r}"));

                tokio::time::sleep(Duration::from_secs(3)).await;

                log("[repro] probe tonic start".into());
                let t = do_tonic().await;
                log(format!("[repro] probe tonic => {t}"));

                log("[repro] probes done".into());
            });

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
